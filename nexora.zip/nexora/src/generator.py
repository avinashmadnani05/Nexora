"""Deterministic synthetic organization and activity generation."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import random
from typing import Any

from .database import build_database

DEPARTMENTS = ["Engineering", "Product", "Marketing", "Sales", "HR", "Finance"]
BASE_DATE = datetime(2026, 7, 23, 9, 0, tzinfo=timezone.utc)


def _employee_catalog() -> list[dict[str, Any]]:
    first_names = ["Aarav", "Maya", "Liam", "Sofia", "Noah", "Priya", "Ethan", "Zoe", "Mateo", "Nina"]
    last_names = ["Shah", "Chen", "Williams", "Patel", "Okafor", "Garcia"]
    roles = {
        "Engineering": [("Platform", "Backend Engineer", ["Python", "APIs", "AWS"]), ("Web", "Frontend Engineer", ["React", "TypeScript", "UX"]), ("Data", "Data Engineer", ["SQL", "Pipelines", "Analytics"]), ("Infrastructure", "DevOps Engineer", ["Kubernetes", "AWS", "Observability"])],
        "Product": [("Product", "Product Manager", ["Roadmaps", "Discovery", "Prioritization"]), ("Design", "Product Designer", ["Figma", "Research", "Prototyping"])],
        "Marketing": [("Growth", "Growth Marketer", ["Campaigns", "SEO", "Analytics"]), ("Brand", "Content Strategist", ["Content", "Brand", "Events"])],
        "Sales": [("Enterprise", "Account Executive", ["B2B", "Negotiation", "CRM"]), ("Success", "Customer Success Manager", ["Onboarding", "Renewals", "Discovery"])],
        "HR": [("People", "People Partner", ["Hiring", "Onboarding", "Culture"]), ("Talent", "Recruiter", ["Sourcing", "Interviews", "Employer Brand"])],
        "Finance": [("FP&A", "Financial Analyst", ["Budgets", "Forecasting", "Excel"]), ("Operations", "Finance Operations", ["Expenses", "Controls", "Vendors"])],
    }
    employees = []
    for index in range(60):
        department = DEPARTMENTS[index % len(DEPARTMENTS)]
        team, role, skills = roles[department][(index // len(DEPARTMENTS)) % len(roles[department])]
        name = f"{first_names[index % len(first_names)]} {last_names[index // len(first_names)]}"
        employees.append({"id": f"EMP-{index + 1:03d}", "name": name, "department": department, "team": team, "role": role, "skills": skills, "manager": "EMP-001" if index else None})
    return employees


def _projects(employees: list[dict[str, Any]]) -> list[dict[str, Any]]:
    specs = [
        ("PRJ-001", "Payments Reliability", "Engineering", "in progress", 58),
        ("PRJ-002", "Atlas Analytics", "Engineering", "at risk", 47),
        ("PRJ-003", "Customer Insights", "Product", "in progress", 42),
        ("PRJ-004", "Q3 Launch Campaign", "Marketing", "at risk", 36),
        ("PRJ-005", "Enterprise Expansion", "Sales", "in progress", 63),
        ("PRJ-006", "Nexora Onboarding", "HR", "in progress", 71),
        ("PRJ-007", "FY27 Planning", "Finance", "in progress", 52),
        ("PRJ-008", "Identity Refresh", "Engineering", "in progress", 76),
        ("PRJ-009", "Mobile Workspace", "Product", "in progress", 29),
        ("PRJ-010", "Partner Webinar", "Marketing", "complete", 100),
        ("PRJ-011", "Renewal Health", "Sales", "in progress", 68),
        ("PRJ-012", "People Operations", "HR", "in progress", 55),
    ]
    counters = {department: 0 for department in DEPARTMENTS}
    projects = []
    for index, (project_id, name, department, status, progress) in enumerate(specs):
        department_employees = [e for e in employees if e["department"] == department]
        owner = department_employees[counters[department] % len(department_employees)]
        counters[department] += 1
        members = [owner["id"]] + [e["id"] for e in department_employees[1:4]]
        projects.append({"id": project_id, "name": name, "department": department, "owner": owner["id"], "members": members, "status": status, "progress": progress, "start_date": (BASE_DATE - timedelta(days=26 - index)).date().isoformat(), "deadline": (BASE_DATE + timedelta(days=8 + index)).date().isoformat()})
    return projects


def _tasks(projects: list[dict[str, Any]], employees: list[dict[str, Any]]) -> list[dict[str, Any]]:
    templates = ["Define acceptance criteria", "Review implementation", "Validate stakeholder feedback", "Prepare launch checklist", "Resolve dependency", "Publish weekly update"]
    tasks = []
    for index in range(60):
        project = projects[index % len(projects)]
        owner = project["members"][index % len(project["members"])]
        status = "blocked" if index in {0, 1, 12, 18} else ("done" if index % 5 == 0 else "in progress")
        tasks.append({"id": f"TASK-{index + 1:03d}", "key": f"{project['id'].replace('PRJ', 'NX')}-{index + 101}", "title": f"{templates[index % len(templates)]} - {project['name']}", "project_id": project["id"], "assignee": owner, "status": status})
    return tasks


def _activity(timestamp: datetime, employee: dict[str, Any], project: dict[str, Any], activity_type: str, content: str, task: dict[str, Any] | None = None) -> dict[str, Any]:
    return {"timestamp": timestamp.isoformat(), "employee": employee["id"], "department": employee["department"], "project": project["id"], "activity_type": activity_type, "content": content, "related_task": task["id"] if task else None}


def _activities(employees: list[dict[str, Any]], projects: list[dict[str, Any]], tasks: list[dict[str, Any]], days: int = 30) -> list[dict[str, Any]]:
    rng = random.Random(42)
    by_id = {e["id"]: e for e in employees}
    by_project = {p["id"]: p for p in projects}
    activities = []
    for day in range(days):
        for offset in range(10):
            project = projects[(day * 3 + offset) % len(projects)]
            employee = by_id[project["members"][offset % len(project["members"])] ]
            task = tasks[(day * 2 + offset) % len(tasks)]
            kind = ["GitHub commit", "Jira task update", "Slack message", "Meeting", "Email", "task completion", "GitHub pull request"][offset % 7]
            content = f"Progress update on {project['name']}: {task['title'].lower()}"
            activities.append(_activity(BASE_DATE + timedelta(days=day, hours=offset % 8, minutes=rng.randint(0, 45)), employee, project, kind, content, task))
    def add(day: int, employee_id: str, project_id: str, kind: str, content: str, task_id: str | None = None) -> None:
        activities.append(_activity(BASE_DATE + timedelta(days=day, hours=11), by_id[employee_id], by_project[project_id], kind, content, next((t for t in tasks if t["id"] == task_id), None)))
    eng = [e["id"] for e in employees if e["department"] == "Engineering"]
    add(3, eng[0], "PRJ-001", "Slack message", "Webhook retries are failing because the production queue policy is still pending.", "TASK-001")
    add(4, eng[3], "PRJ-001", "blocker", "Infrastructure dependency: queue policy and alert routing need approval.", "TASK-001")
    add(6, eng[1], "PRJ-001", "Meeting", "Payments dependency review: DevOps will ship the queue policy before the next deploy.", "TASK-001")
    add(10, eng[3], "PRJ-001", "decision", "Decision: use the shared retry queue and standard alert thresholds.", "TASK-002")
    add(15, eng[3], "PRJ-001", "task completion", "Queue policy deployed and verified in staging.", "TASK-002")
    add(17, eng[0], "PRJ-001", "GitHub pull request", "PR #183 implements webhook retries and is ready for review.", "TASK-001")
    add(19, eng[0], "PRJ-001", "task completion", "Webhook task completed after infrastructure dependency resolved.", "TASK-001")
    add(8, eng[2], "PRJ-002", "Jira task update", "Atlas event model adds funnel cohorts and retention dimensions.", "TASK-013")
    add(9, eng[5], "PRJ-002", "Slack message", "I am building a parallel event aggregation path for the analytics dashboard.", "TASK-019")
    add(11, eng[2], "PRJ-002", "Meeting", "Analytics overlap review: two teams are implementing the same event dimensions.", "TASK-013")
    add(12, eng[0], "PRJ-002", "decision", "Decision: consolidate on the Atlas event model; retire the duplicate dashboard path.", "TASK-019")
    product = [e["id"] for e in employees if e["department"] == "Product"]
    add(13, product[0], "PRJ-003", "decision", "Roadmap decision: Customer Insights ships cohort exports before mobile parity.", "TASK-025")
    marketing = [e["id"] for e in employees if e["department"] == "Marketing"]
    add(20, marketing[0], "PRJ-004", "blocker", "Launch campaign is behind schedule: creative review and customer proof points are late.", "TASK-019")
    add(23, marketing[1], "PRJ-004", "project update", "Campaign recovery plan approved with a smaller launch scope.", "TASK-020")
    hr = [e["id"] for e in employees if e["department"] == "HR"]
    add(22, hr[0], "PRJ-006", "Email", "New hire onboarding is underway; laptop, buddy, and first-week plan are ready.", "TASK-031")
    add(25, eng[0], "PRJ-001", "decision", "Payments technical decision is currently concentrated with two engineers; document the runbook.", "TASK-001")
    return sorted(activities, key=lambda item: item["timestamp"])


def generate_demo_data(output_dir: str | Path) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    employees = _employee_catalog()
    projects = _projects(employees)
    tasks = _tasks(projects, employees)
    activities = _activities(employees, projects, tasks)
    company = {"name": "Nexora Technologies", "generated_at": datetime.now(timezone.utc).isoformat(), "departments": DEPARTMENTS, "days": 30}
    records = {"company": company, "employees": employees, "projects": projects, "tasks": tasks, "activities": activities}
    for name, value in records.items():
        (output / f"{name}.json").write_text(json.dumps(value, indent=2), encoding="utf-8")
    build_database(records, output.parent / "nexora.db")
    return records
