# Nexora Organizational Intelligence

A local Streamlit proof-of-concept for exploring synthetic organizational activity. It generates a 60-person fictional company, 12 connected projects, 60 tasks, and 30 days of activity. Insights are explicitly framed as activity/involvement signals, with supporting evidence and confidence.

## Run

```powershell
cd nexora
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python scripts\generate_demo.py
streamlit run app.py
```

Set `OPENAI_API_KEY` to enable an optional LLM answer path. Without it, Ask Organization AI uses deterministic mock analysis and remains fully functional. The generated JSON under `data/` is the clean workflow/API contract; `database.py` can index activities in SQLite for later n8n integration.
